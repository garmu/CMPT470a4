int main()
{
  int i,j;
   for (i = 1;i <= 24;i++)
     {
       for (j = i; j < 24; j++)
	 {
	    printf("%d",i);
	 }
     }
   return 0;
}
