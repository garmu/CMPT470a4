int main()
{
  int i,j;
   for (i = 1;i <= 24;i++)
     {
       while (j <= 2)
	 {
	   j++;
	   printf("%d\n", i);
	 }
     }
   return 0;
}
