int returnANumber(){int variable,number,c;        return 42;
}