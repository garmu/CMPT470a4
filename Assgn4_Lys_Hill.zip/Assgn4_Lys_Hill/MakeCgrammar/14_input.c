int main()
{
   int i;
   for (i = 1;i <= 24;i++)
      printf("H\n");
   return 0;
}
