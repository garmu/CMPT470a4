int test()
{
   int i, a;
   while (i < 10)
   {
      i++;
      if (i == 5)
         break;
   }

   for(a = 0; a < 10; a++){

   		a = 2;

   		if(a == 3)
   			break;

   }

   return 0;
}
