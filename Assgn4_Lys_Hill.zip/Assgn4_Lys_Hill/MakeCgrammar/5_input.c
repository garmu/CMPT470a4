int main()
{
   unsigned int a;
   signed int b;
   return 0;
}
