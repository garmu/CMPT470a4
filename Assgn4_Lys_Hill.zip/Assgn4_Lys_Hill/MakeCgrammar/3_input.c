int main()
{
  int a,b,c;
   return 0;
}
