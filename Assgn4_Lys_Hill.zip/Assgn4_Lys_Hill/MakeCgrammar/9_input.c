int main()
{
   int mark;
   char pass;
   scanf("%d",&mark);
   if (mark > 40)
      pass = 'y';
   return 0;
}
