int main()
{
  int a;
  char b;
  return 0;
}
