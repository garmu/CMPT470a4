#include<stdio.h>

int main()
{
   int i;
   while (i < 10)
   {
      i++;
      continue;
      printf("Hello\n");
   }
   return 0;
}
