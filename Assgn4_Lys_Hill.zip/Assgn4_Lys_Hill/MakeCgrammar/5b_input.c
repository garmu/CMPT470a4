int print_number()
{
   unsigned int a = 1;
   signed int c = 42; 
   string text = "hello world";
     return 0;
}