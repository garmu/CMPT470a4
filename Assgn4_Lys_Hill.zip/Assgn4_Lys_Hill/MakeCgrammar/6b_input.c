int testfunction()
						{
   int twenty;
   char character = 'char';
   string hello = "hello world!";
   							c = 3;
   z = 'Z';return 0;}
