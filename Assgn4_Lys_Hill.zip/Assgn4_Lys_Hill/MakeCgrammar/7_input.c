int main()
{
   int a,b;
   a = 5;
   b = a + 3;
   a = a - 3;
   return 0;
}
