int testFunction()
{
   int a,b;
   a = 5;
   b = a + 34;
   a = a - b;
   char *string = "hello world";
   return 1;
}