int newFunction()
{const float pi = 3.14; const float otherpi = 6.24; int number1 = 1;return 3;
}
