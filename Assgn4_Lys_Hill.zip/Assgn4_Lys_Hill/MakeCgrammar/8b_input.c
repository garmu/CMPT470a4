int newTestFunction()
{
   int a;
   char b;
   scanf("%d",&a);
   a = a * 2;
   b = a -2;
   printf("The answer is %d",a);
   scanf("Something to scan....&d", &a);
   return 0;
}
