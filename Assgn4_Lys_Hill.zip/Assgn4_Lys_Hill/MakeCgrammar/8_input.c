int main()
{
   int a;
   scanf("%d",&a);
   a = a * 2;
   printf("The answer is %d",a);
   return 0;
}
