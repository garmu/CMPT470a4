int testfunction(){
   int mark;
   char fail;
			scanf("%d",&mark);
   if (mark < 50){
      fail = 'y';
   printf("better luck next time!\n");}
   return 0;
}
