#include<stdio.h>

int main()
{
   int i;
   while (i < 20)
   {
      i++;
      if(i == 5){
      	continue;
      }
      	else{
      		printf("Hello\n");
      	}
      
      
   }
   return 0;
}
