int main()
{
   int i,times;
   scanf("%d",&times);
   i = 0;
   while (i <= times)
   {
      i++;
      printf("%d\n",i);
   }
   return 0;
}
