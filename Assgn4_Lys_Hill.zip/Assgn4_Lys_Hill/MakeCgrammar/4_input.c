int main()
{
   const float pi = 3.14;
   return 0;
}
