int main()
{
   int a;
   char b;
   a = 3;
   b = 'H';
   return 0;
}
