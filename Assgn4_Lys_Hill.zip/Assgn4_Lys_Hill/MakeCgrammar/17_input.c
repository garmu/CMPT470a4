int main()
{
   int i;
   while (i < 10)
   {
      i++;
      if (i == 5)
         break;
   }
   return 0;
}
