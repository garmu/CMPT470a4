int test()
{
   int i;
   for (i = 20;i > 24;i--)
      printf("H\n");
   return 0;
}
